# ring 1.0.0 (2017-04-24)

* Initial CRAN release
