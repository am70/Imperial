#include <R.h>
#include <Rinternals.h>
SEXP assert_scalar_size(SEXP x, SEXP r_name);
