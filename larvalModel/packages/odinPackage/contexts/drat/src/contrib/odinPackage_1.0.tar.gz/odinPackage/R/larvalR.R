function (dE, dL, dP, uoE, uoL, uP, uM, Y, S, tr, sf, dt, n, 
          Emax, rF, user = list(dE = dE, dL = dL, dP = dP, uoE = uoE, 
                                uoL = uoL, uP = uP, uM = uM, Y = Y, S = S, tr = tr, sf = sf, 
                                dt = dt, n = n, Emax = Emax, rF = rF)) 
{
  .R6_odind187f495314$new(user = user)
}