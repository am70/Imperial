#' @useDynLib odinPackage
#' @importFrom odin odin
#' @exportPattern ^[^\\.]
NULL