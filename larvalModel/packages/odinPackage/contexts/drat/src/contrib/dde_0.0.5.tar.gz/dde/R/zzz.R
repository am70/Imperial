##' @useDynLib dde, .registration = TRUE
NULL
