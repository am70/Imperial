library(testthat)
library(rcmdshlib)

test_check("rcmdshlib")
